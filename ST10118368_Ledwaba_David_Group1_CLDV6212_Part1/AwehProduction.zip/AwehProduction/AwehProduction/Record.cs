﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AwehProduction
{
    public class Record
    {
        private string ID;


        public Record() 
        {
            ID = null;
        }

        public Record(string ID) 
        {
            this.ID = ID;
        }

        public string iD
        {
            get{ return ID; }
            set{ ID = value; }
        }

    }
}
