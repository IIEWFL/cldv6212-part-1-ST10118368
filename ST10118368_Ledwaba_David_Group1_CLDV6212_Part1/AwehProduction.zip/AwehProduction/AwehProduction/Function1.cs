using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;

namespace AwehProduction
{
    public static class Vaccination
    {

        [FunctionName("Vaccination")]
        public static async Task<IActionResult> Run(
            [HttpTrigger(AuthorizationLevel.Function, "get", "post", Route = null)] HttpRequest req,
            ILogger log)
        {
            log.LogInformation("C# HTTP trigger function processed a request.");

            Record record = new Record();

            string idNum = req.Query["idNum"];
            string responseMessage = null;
            
            record.iD = idNum;

            responseMessage = getStatus(record.iD);
            
            return new OkObjectResult(responseMessage);
        }

        public static string getStatus(string id)
        {
            //Checking ID vaccination status recorded.
            switch (id)
            {
                case "9910125015083":
                    return "Individual is Vaccinated..";
                    break;
                case "9810125015082":
                    return "Individual is Not Vaccinated.!";
                    break;
                case "0101014815083":
                    return "Individual is Vaccinated..";
                    break;
                case "0005280015087":
                    return "Individual is Not Vaccinated.!";
                    break;
                case "0501014816083":
                    return "Individual is Not Vaccinated.!";
                    break;
                case "8505288055081":
                    return "Individual is Vaccinated..";
                    break;
                default:
                    return "***Please provide  vaild ID/Passport number**** \n ==>example: yymmddxxxxnnn<== \n *** If valid, then ID/Passport not found***";
            }
        }

        //int num1 = int.Parse(req.Query["num1"]);
        //int num2 = int.Parse(req.Query["num2"]);

        //int result = num1 + num2;

        //switch (record.iD)
        //{
        //    case "9910125015083":
        //        responseMessage = "Individual has been Vaccinated..";
        //        break;
        //    case "9810125015083":
        //        responseMessage = "Individual has not Vaccinated.!";
        //        break;
        //}

        //return new OkObjectResult(result);
    }
}
